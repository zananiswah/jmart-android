package com.zanaJmartAK.jmart_android.model;

public class Store {
    public String address;
    public String name;
    public String phoneNumber;
}
