package com.zanaJmartAK.jmart_android.model;

public class Account extends Serializable{
    public double balance;
    public String name;
    public String email;
    public String password;
    public Store store;
}
