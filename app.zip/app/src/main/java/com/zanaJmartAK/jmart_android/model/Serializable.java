package com.zanaJmartAK.jmart_android.model;

public class Serializable {
    public final int id = -1;
}
